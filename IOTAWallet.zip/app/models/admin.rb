class Admin < ApplicationRecord
end
