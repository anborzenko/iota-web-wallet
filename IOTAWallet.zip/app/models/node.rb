class Node < ApplicationRecord
end
