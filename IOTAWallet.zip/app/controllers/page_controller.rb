class PageController < ApplicationController
  def index
  end

  def about
  end

  def help

  end
end
