class NodesController < ApplicationController
  # GET /nodes
  # GET /nodes.json
  def index
  end
end
