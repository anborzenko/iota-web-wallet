require "application_system_test_case"

class PendingTransactionsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit pending_transactions_url
  #
  #   assert_selector "h1", text: "PendingTransaction"
  # end
end
