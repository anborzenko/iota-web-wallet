require "application_system_test_case"

class WalletsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit wallets_url
  #
  #   assert_selector "h1", text: "Wallet"
  # end
end
