require "application_system_test_case"

class NodesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit nodes_url
  #
  #   assert_selector "h1", text: "Node"
  # end
end
